<?php

$con = mysqli_connect('localhost', 'rdlpk_admin', 'creative123admin', 'rdlpk_db1');


?>