<style>.wc-text .btn-info {
padding:10px 15px;
border-radius:5px;
color:#fff;
text-decoration:none;
}
.wc-text .btn-info:hover {
background:#09F;
} </style>
<div class="span5 wc-text">
<a class="btn-info button" href="rand">Generate Random List</a><br>
<a class="btn-info button" href="add">Add Applicant </a><br>
<a class="btn-info button" href="applist">Applicant List</a><br>
<a class="btn-info button" href="project_wise">Project Wise List</a><br>

</div>

