<div class="container-fluid mytext">
      <div class=" col-lg-12"><h2>New Registration</h2>
  </div>
 
  <form role="form" action="create" method="post" enctype="multipart/form-data">
    <div class="form-group">
      <label for="firstname" class="col-md-2">
       Member ID:
      </label>
      <div class="col-md-5">
        <input type="text" class="form-control" id="mem_id" name="mem_id" placeholder="Enter Member ID">
      </div> 
      </div>
 
    <div class="form-group">
      <label for="name" class="col-md-2">
        Name:
      </label>
      <div class="col-md-5">
        <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name">
      </div>
  
          <div class="form-group">
      <label for="lastname" class="col-md-2">
        S/O,W/O,D/O:
      </label>
      <div class="col-md-5">
        <input type="text" class="form-control" id="sodowo" name="sodowo" placeholder="Enter Son of wife of,daughter of">
      </div>
 
    </div>
    
    
     <div class="form-group">
      <label for="lastname" class="col-md-2">
        CNIC:
      </label>
      <div class="col-md-5">
        <input type="text" class="form-control" name="cnic" id="cnic" placeholder="Enter CNIC">
      </div>
 
    </div>
    
     <div class="form-group">
      <label for="lastname" class="col-md-2">
        Address:
      </label>
      <div class="col-md-5">
        <input type="text" class="form-control" name="cnic" id="cnic" placeholder="Enter Address">
      </div>
 
    </div>
   
      <div class="form-group">
      <label for="lastname" class="col-md-2">
        Country:
      </label>
      <div class="col-md-5">
         <select name="country" id="country">
     <option value="pakistan">Pakistan</option>
     <option value="uk">UK</option>
     <option value="usa">USA</option>
     <option value="india">INDIA</option>
     <option value="China">China</option>
     <option value="spain">Spain</option>
     <option value="canada">Canada</option>
     <option value="australia">Australia</option>
            
     </select>
      </div>
 
    </div>
      <div class="form-group">
      <label for="lastname" class="col-md-2">
        City:
      </label>
      <div class="col-md-5">
         <select name="city" id="city">
     <option value="islamabad">Islamabad</option>
     <option value="rawalpindi">Rawalpindi</option>
     <option value="quetta">Quetta</option>
     <option value="karachi">Karachi</option>
     <option value="peshawer">Peshawer</option>
     <option value="multan">Multan</option>
     <option value="jehlum">Jehlum</option>
     <option value="gujjarkhan">Gujjar Khan</option>
     <option value="london">London</option>
     <option value="washington">Washington</option>
     <option value="beijing">Beijing</option>
     <option value="barcelona">Barcelona</option>
     <option value="sydney">Sydney</option>
            
     </select>
      </div>
    </div>
    <div class="form-group">
      <label for="emailaddress" class="col-md-2">
        Email address:
      </label>
      <div class="col-md-5">
        <input type="email" class="form-control" id="email" name="email" placeholder="Enter email address">
        <p class="help-block">
          Example: yourname@domain.com
        </p>
      </div>
 
 
    </div>
 
    <div class="form-group">
      <label for="password" class="col-md-2">
        Password:
      </label>
      <div class="col-md-5">
       <input type="password" value="" name="password" id="password" placeholder="**********"  class="form-control">
                           
        <p class="help-block">
          Min: 6 characters (Alphanumeric only)
        </p>
      </div>
 
 
    </div>
    <div class="form-group">
      <label for="password" class="col-md-2">
        Confirm Password:
      </label>
      <div class="col-md-5">
       <input type="password" value="" name="confirm_password" id="con_password" placeholder="**********"  class="form-control">
                           
      
      </div>
 
 
    </div>
 
    <div class="form-group">
      <label for="country" class="col-md-2">
        Country:
      </label>
      <div class="col-md-5">
        <select name="country" id="country" class="form-control">
          <option>--Please Select--</option>
          <option>India</option>
          <option>United States</option>
          <option>Canada</option>
          <option>United Kingdom</option>
          <option>Others</option>
        </select>
      </div>
 
 
    </div>
 
    <div class="form-group">
      <label for="uploadimage" class="col-md-2">
        Upload Image:
      </label>
      <div class="col-md-5">
        <input type="file" name="image" id="image">
        <p class="help-block">
          Allowed formats: jpeg, jpg, gif, png
        </p>
      </div>
 
 
    </div>
 
    <div class="checkbox">
            <div class="col-md-5">
        <label>
        <input name="agree" type="checkbox" value="1" class="float-left" id="checkbox">Terms and Conditions</label>
      </div>
 
 
    </div>
 
    <div class="col-md-12">
     
      
      
        <button type="submit" class="btn btn-primary">
          Register
        </button>
      
    </div>
  </form>
  </div>




                </div>
            </div>
        </div>
</div>
  </section>