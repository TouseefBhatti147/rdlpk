<?php
    return  array (
            'host' => 'localhost',
            'username' => 'root',
            'db_name' => 'rdlpk_db1dev',
            'password' => ''
        )
?>